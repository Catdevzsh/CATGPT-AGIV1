import os
os.environ['DISPLAY'] = ':0'
os.system('xrandr -s 800x600')